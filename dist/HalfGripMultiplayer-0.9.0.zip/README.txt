﻿Half Grip Multiplayer 0.9.0
===========================

Install
1. Install BepInEx 5 (x64 Mono) into the Half Grip Demo folder if you do not have it yet.
2. Extract this zip into the game root (the folder with HalfGrip.exe).
   You should get:  <game>\BepInEx\plugins\HalfGripMultiplayer\HalfGripMultiplayer.dll
3. Launch the game. Overlay: F6. Steam host: F7. Leave: F8.

LAN dual-client lab uses scripts\launch-dual.ps1 from the repo.

Money / shop / loadout stay per-player.
